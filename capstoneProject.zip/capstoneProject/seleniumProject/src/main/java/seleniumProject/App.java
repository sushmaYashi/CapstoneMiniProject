package seleniumProject;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class App {
	public static void main(String[] args) {

		System.setProperty("webdriver.edge.driver", "E:\\Selenium Projects\\msedgedriver.exe");
		System.setProperty("webdriver.http.factory", "jdk-http-client");

		WebDriver driver = new EdgeDriver();
		driver.manage().window().maximize();

		//driver.manage().deleteAllCookies();

		driver.get("https://www.automationanywhere.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

}
}