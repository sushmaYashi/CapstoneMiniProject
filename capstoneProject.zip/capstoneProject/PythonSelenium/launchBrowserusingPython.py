from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("http://the-internet.herokuapp.com/")
driver.maximize_window();
print("Application title is ",driver.title)


Checkboxes = driver.find_element(By.CSS_SELECTOR,"a[href='/checkboxes']")
Checkboxes.click()
checkbox1 = driver.find_element(By.XPATH,"//form[@id='checkboxes']/input[1]")
print(checkbox1.is_selected())
assert checkbox1.is_selected() == False
checkbox2 = driver.find_element(By.XPATH,"//form[@id='checkboxes']/input[2]")
print(checkbox2.is_selected())
assert checkbox2.is_selected() == True
driver.back()

fileupload1 = driver.find_element(By.CSS_SELECTOR,"a[href='/upload']")
fileupload1.click()
time.sleep(3)
driver.find_element(By.XPATH,"//*[@id='file-upload']").send_keys("C:\\Users\\LENOVO\\Desktop\\test.txt")
driver.find_element(By.ID,"file-submit").click()
time.sleep(30)
print("Successfully uploaded the file ")


driver.quit()